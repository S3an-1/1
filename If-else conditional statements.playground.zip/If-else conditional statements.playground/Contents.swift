let isPictureVisible = true

if isPictureVisible {
    print("Picture is visible")
}
let isRestaurantFound = false


if isRestaurantFound == false {
    print("Restaurant was not found")
}
let drinkingAgeLimit = 21
var customerAge = 19

if customerAge < drinkingAgeLimit {
    print("under age limit")
} else {
    print("Over age limit")
}

