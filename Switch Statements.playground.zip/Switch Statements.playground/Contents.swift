

var trafficLight = "yellow"

if trafficLight == "red" {
    print("Stop")
} else if trafficLight == "yellow" {
    print("Caution")
} else if trafficLight == "green" {
    print("Go")
} else {
    print("invalid color")
}
trafficLight = "yellow"
switch trafficLight {
case "red":
    print("Stop")
case "yellow":
    print("Caution")
case "green":
    print("Go")
default:
    print("invalid color")
}
