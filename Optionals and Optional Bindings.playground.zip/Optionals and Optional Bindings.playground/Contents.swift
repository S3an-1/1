var spouseName: String?
spouseName = "Lydia"
print(spouseName)

if let spouse = spouseName {
    let greeting = "Hello, " + spouse
    print(greeting)
}
